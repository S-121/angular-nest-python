import {
  Directive,
  ViewContainerRef,
  ComponentFactoryResolver,
  OnInit,
  Input,
  EventEmitter,
} from '@angular/core';
import {
  RevenueComponent,
  KeywordComponent,
  TopPerformingComponent,
} from '../components';
import { GridsterItem } from 'angular-gridster2';

interface WidgetItem {
  type: string;
}
const COMPONENTS = new Map()
  .set('revenue', RevenueComponent)
  .set('keyword', KeywordComponent)
  .set('top-performing', TopPerformingComponent);

@Directive({
  selector: '[widgetItem]',
})
export class WidgetItemDirective implements OnInit {
  @Input() widget: WidgetItem;
  @Input() resizeEvent: EventEmitter<GridsterItem>;

  constructor(
    public viewContainerRef: ViewContainerRef,
    private componentFactoryResolver: ComponentFactoryResolver
  ) {}

  ngOnInit() {
    this.loadComponent();
  }

  loadComponent() {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory<
      any
    >(COMPONENTS.get(this.widget.type));

    this.viewContainerRef.clear();

    const componentRef = this.viewContainerRef.createComponent(
      componentFactory
    );
    componentRef.instance.widget = this.widget;
    componentRef.instance.resizeEvent = this.resizeEvent;
  }
}
