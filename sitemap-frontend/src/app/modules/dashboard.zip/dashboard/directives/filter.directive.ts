import {
  Directive,
  ViewContainerRef,
  ComponentFactoryResolver,
  OnInit,
  Input,
  EventEmitter,
} from '@angular/core';
import { DateRangeComponent, RadioComponent } from '../components';

interface FilterItem {
  type: string;
}
const COMPONENTS = new Map()
  .set('dateRange', DateRangeComponent)
  .set('radio', RadioComponent);

@Directive({
  selector: '[filterItem]',
})
export class FilterItemDirective implements OnInit {
  @Input() filter: FilterItem;
  constructor(
    public viewContainerRef: ViewContainerRef,
    private componentFactoryResolver: ComponentFactoryResolver
  ) {}

  ngOnInit() {
    this.loadComponent();
  }

  loadComponent() {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory<
      any
    >(COMPONENTS.get(this.filter.type));

    this.viewContainerRef.clear();

    const componentRef = this.viewContainerRef.createComponent(
      componentFactory
    );
    componentRef.instance.filter = this.filter;
  }
}
