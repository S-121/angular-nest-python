import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GridsterModule } from 'angular-gridster2';
import { DragulaModule } from 'ng2-dragula';
import * as echarts from 'echarts'; // FIXME

import { DashboardContainerComponent } from './dashboard-container/dashboard-container.component';
import { Routes, RouterModule } from '@angular/router';
import {
  LeftSideComponent,
  FilterBarComponent,
  DateRangeComponent,
  RadioComponent,
  RevenueComponent,
  KeywordComponent,
  TopPerformingComponent,
} from './components';
import { ClarityModule } from '@clr/angular';
import { FilterItemDirective, WidgetItemDirective } from './directives';
import { FormsModule } from '@angular/forms';
import { NgxEchartsModule } from 'ngx-echarts';
import { SharedModule } from 'src/app/shared';

const routes: Routes = [
  {
    path: '',
    component: DashboardContainerComponent,
  },
];

@NgModule({
  declarations: [
    DashboardContainerComponent,
    LeftSideComponent,
    FilterBarComponent,
    DateRangeComponent,
    RadioComponent,
    FilterItemDirective,
    WidgetItemDirective,
    RevenueComponent,
    KeywordComponent,
    TopPerformingComponent,
  ],
  imports: [
    SharedModule,
    CommonModule,
    FormsModule,
    ClarityModule,
    RouterModule.forChild(routes),
    GridsterModule,
    DragulaModule.forRoot(),
    NgxEchartsModule.forRoot({
      echarts,
    }),
  ],
  entryComponents: [
    DateRangeComponent,
    RadioComponent,
    RevenueComponent,
    KeywordComponent,
    TopPerformingComponent,
  ],
})
export class DashboardModule {}
