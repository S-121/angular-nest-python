import {
  Component,
  OnInit,
  EventEmitter,
  ChangeDetectorRef,
} from '@angular/core';
import {
  GridsterConfig,
  GridsterItem,
  DisplayGrid,
  GridType,
  CompactType,
} from 'angular-gridster2';
import { v4 as uuidv4 } from 'uuid';

import { DragulaService } from 'ng2-dragula';
import { DashboardService } from '../services';

@Component({
  selector: 'app-dashboard-container',
  templateUrl: './dashboard-container.component.html',
  styleUrls: ['./dashboard-container.component.scss'],
})
export class DashboardContainerComponent implements OnInit {
  options: GridsterConfig;
  widgets: Array<GridsterItem>;
  resizeEvent: EventEmitter<GridsterItem> = new EventEmitter<GridsterItem>();
  constructor(
    private dragulaService: DragulaService,
    private readonly __dashboardService: DashboardService,
    private __changeDetectorRef: ChangeDetectorRef
  ) {
    let filters = this.dragulaService.find('filters');
    let widgets = this.dragulaService.find('widgets');
    if (!filters) {
      filters = this.dragulaService.createGroup('filters', {
        removeOnSpill: true,
        revertOnSpill: true,
        accepts: (el, target, source, sibling) => {
          const { id: targetId } = target;
          const { id: elemId } = el;
          const { filters } = this.__dashboardService;
          if (
            filters &&
            filters[targetId] &&
            filters[targetId].map((item) => item.id).includes(+elemId)
          ) {
            return false;
          }
          return true;
        },
        copy: true,
        copyItem: (item) => {
          return { ...item };
        },
      });
      const { drake } = filters;
      drake.on('drag', (el, source) => {
        const { id } = source;
        if (!['filters'].includes(id)) {
          drake.cancel();
        }
      });
    }

    if (!widgets) {
      widgets = this.dragulaService.createGroup('widgets', {
        removeOnSpill: true,
        revertOnSpill: true,
        copy: true,
        copyItem: (item) => {
          return { ...item, id: uuidv4() };
        },
      });
      const { drake } = widgets;
      drake.on('drag', (el, source) => {
        this.toggleShadow();
        const { id } = source;
        if (!['widgets'].includes(id)) {
          drake.cancel();
        }
      });
      drake.on('dragend', (el) => {
        this.toggleShadow();
      });
      drake.on('over', (el, container, source) => {
        this.toggleHidden(el, container);
      });
      drake.on('out', (el, container, source) => {
        this.toggleHidden(el, container);
      });
    }
  }

  ngOnInit() {
    this.options = {
      gridType: GridType.ScrollVertical,
      compactType: CompactType.CompactUpAndLeft,
      defaultItemCols: 6,
      defaultItemRows: 2,
      fixedColWidth: 60,
      fixedRowHeight: 60,
      pushItems: false,
      draggable: {
        enabled: true,
      },
      resizable: {
        enabled: true,
      },
      displayGrid: DisplayGrid.None,
      itemResizeCallback: (item) => {
        this.resizeEvent.emit(item);
      },
    };

    this.widgets = [];
  }

  changedOptions(): void {
    if (this.options.api && this.options.api.optionsChanged) {
      this.options.api.optionsChanged();
    }
  }
  removeWidget($event, widget) {
    this.widgets.splice(
      this.widgets.findIndex((item) => item.id === widget.id),
      1
    );
    this.changedOptions();
    this.__changeDetectorRef.detectChanges();
  }

  toggleShadow() {
    ['widgetsGrid'].forEach((id) => {
      document.getElementById(id).classList.toggle('shadow');
    });
  }
  toggleHidden(el, container) {
    const { id } = container;
    if (id === 'widgetsGrid') {
      el.classList.toggle('hidden');
      document.getElementById(id).classList.toggle('focus');
    }
  }
}
